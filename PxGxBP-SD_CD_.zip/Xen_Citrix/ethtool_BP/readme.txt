 	        Bypass Control via Ethtool    

NOTE: Please check that bpctl_mod driver is loaded!
ethtool -b|--show-bypass DEVNAME|bus:slot.function|all Show all bypass options status
ethtool -b|--show-bypass DEVNAME|bus:slot.function|all <option> Show defined options status
                [is-bypass] check if device is a Bypass/TAP controlling device
                [bypass-slave] get the second port participate in the Bypass/TAP pair
                [bypass-info] get bypass/TAP info
                [bypass-caps] obtain Bypass/TAP capabilities information
                [wd-set-caps] obtain watchdog timer settings capabilities
                [get-bypass-change] get change of Bypass mode state from last status check
                [bypass] get Bypass mode state
                [bypass-pwoff] get Bypass mode at power-off state
                [bypass-pwup] get Bypass mode at power-up state
                [dis-bypass] get Disable Bypass mode state
                [tap] get TAP mode state
                [tap-pwup] get TAP mode at power-up state
                [dis-tap] get Disable TAP mode state
                [disc] get Disconnect mode state
                [disc-pwup] get Disconnect mode at power-up state
                [dis-disc] get Disable Disconnect mode state
                [std-nic] get Standard NIC mode of operation
                [tx] get transmitter state (enabled / disabled)
                [tpl] get Two Port Link state
                [wait-at-pwup] get wait-at-pwup (enabled / disabled)
                [hw-reset] get hw-reset (enabled / disabled)
                [bypass-wd] get WDT state
                [wd-time-expire]  get watchdog expired time
                [wd-exp-mode] WDT expired mode
                [wd-autoreset] WDT autoreset interval, msec (0 for disabling WDT autoreset)
ethtool -B|--bypass DEVNAME|bus:slot.function|all <option> Set bypass options
                [bypass on|off] set Bypass mode state
                [bypass-pwoff on|off] set Bypass mode at power-off state
                [bypass-pwup on|off] set Bypass mode at power-up state
                [dis-bypass on|off] set Disable Bypass mode state
                [tap on|off] set TAP mode state
                [tap-pwup on|off] set TAP mode at power-up state
                [dis-tap on|off] set Disable TAP mode state
                [disc on|off] set Disconnect mode state
                [disc-pwup on|off] set Disconnect mode at power-up state
                [dis-disc on|off] set Disable Disconnect mode state
                [std-nic on|off] set Standard NIC mode of operation
                [tx on|off] set transmitter state (enabled / disabled)
                [tpl on|off] enable/disable Two Port Link
                [wait-at-pwup on|off] set wait-at-pwup (enabled / disabled)
                [hw-reset on|off] get hw-reset (enabled / disabled)
                [bypass-wd N] WDT timeout interval, msec (0 for disabling WDT)
                [wd-exp-mode bypass|tap|disc] WDT expired mode
                [wd-autoreset N] WDT autoreset interval, msec (0 for disabling WDT autoreset)
                [reset-bypass-wd] - reset watchdog timer

Example: ethtool -B eth0 bypass-wd 5000
         ethtool -B all bypass on
         ethtool -B eth0 wd-exp-mode tap
         ethtool -b 0b:00.0 bypass-info
         ethtool -b 0b:00.0

