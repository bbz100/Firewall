/******************************************************************************
* THIS SOFTWARE MODULE CONTAINS CONFIDENTIAL AND TRADESECRET INFORMATION AND  *
* CAN NOT BE COPIED, CHANGED, TRANSLATED, TRANSFERRED VIA MODEM OR/AND E-MAIL,*
* INCLUDED TO ANOTHER SOFTWARE PRODUCT,USED AS A LEARNING MATERIAL WITHOUT    *
* EXPRESS APPROVAL OF SILICOM LTD. ACCESS TO THIS SOURCE IS RESTRICTED ONLY   *
* TO AUTHORIZED EMPLOYEES AND A PERSON, WHO HAVE AN APPROPRIATE LICENSE.      *
*                                                                             *
* Copyright (C) 2008 by Silicom, Ltd. All rights reserved.                    *
* All rights reserved.                                                        *
******************************************************************************/
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <winioctl.h>
#include <setupapi.h>

#include "bpioctrl.h"

//#define DBG 1

// Trace function
#ifndef DBG
#define DBG 0
#endif
#if DBG
#define TRACE_MSG(a)  printf a
#else
#define TRACE_MSG(a)
#endif

#define TRACE_ERR(a)  printf a
#define PRINTF(a)     printf a

#include "instdrv.h"

#define APP_NAME_STR "BPSDApp"
#define APP_VER      "1.6.0.7 10/21/2012"

LPCTSTR DRIVER_SYS_PATH= "system32\\drivers\\" DRIVER_NAME;

//BPSD driver API

//Globals
BYPASS_CMD bpCmd={0};
BYPASS_CMD_STATE bpCmdState={0};
HANDLE   hBPDevice=INVALID_HANDLE_VALUE;

HANDLE   OpenBpDevice(UINT32 Silent){
	if(hBPDevice == INVALID_HANDLE_VALUE){
		hBPDevice=OpenDevice(DEVICE_NAME);
		if (!Silent && (hBPDevice == INVALID_HANDLE_VALUE)) {
			TRACE_ERR(("Can't get a handle to %s\n", DEVICE_NAME));
		}
	}
	return hBPDevice;
}

VOID CloseBpDevice(){
	if(hBPDevice !=INVALID_HANDLE_VALUE){
		CloseHandle (hBPDevice);
		hBPDevice=INVALID_HANDLE_VALUE;
	}
}

BOOL BPIO_CTRL(HANDLE   hBPDevice,PBYPASS_CMD pCmd, PBYPASS_CMD_STATE pCmdState){
	UINT32		BytesWritten=0;
	BOOL		ret=0;
	UINT32		Error;

	if (hBPDevice == INVALID_HANDLE_VALUE) hBPDevice=OpenBpDevice(0);
	if (hBPDevice != INVALID_HANDLE_VALUE){ 
		pCmd->Status=BP_API_VER;
		ret=DeviceIoControl(hBPDevice,BYPASS_IOCTRL_CMD,
			pCmd,sizeof(BYPASS_CMD) ,pCmdState, sizeof(BYPASS_CMD_STATE),&BytesWritten,NULL);
		if(!ret){
			Error = GetLastError();
			switch(Error) {
				case ERROR_INVALID_PARAMETER:
					TRACE_ERR((" BYPASS_IOCTRL_CMD error: ERROR_INVALID_PARAMETER\n"));
					break;
				default:
					TRACE_ERR((" BYPASS_IOCTRL_CMD error %d\n", Error));
			}
		} else if(sizeof(BYPASS_CMD_STATE)!= BytesWritten){
			TRACE_ERR((" BYPASS_IOCTRL_CMD return invalid BytesWritten %d\n",BytesWritten ));
			ret=0;
		}
	}
	return ret;
}

#define BYPASS_CALL(cmd,hBPDevice,pCmd,pCmdState) ((pCmd)->Command=(cmd),BPIO_CTRL((hBPDevice),(pCmd),(pCmdState)))

//

enum _Error_Level{
    Err_OK=0,
    Err_Help,
    Err_Setup,
    Err_Driver,
    Err_Parameters,
    Err_Rescan,
    Err_Last
};

PCHAR cmd_list[]={
    "install",
    "uninstall",
    "start",
    "stop",
    "rescan",
    "devNum",
    "is_bypass",
    "get_cap",
    "set",
    "get",
    "wdt",
    "wdt_auto",
    "help",
    ""
};

enum _CMD_LIST { 
    cmd_unknown=0, 
    cmd_install , 
    cmd_uninstall , 
    cmd_start , 
    cmd_stop , 
    cmd_rescan , 
    cmd_devNum ,
    cmd_is_bypass ,
    cmd_get_cap ,
    cmd_set , 
    cmd_get ,
    cmd_wdt,
    cmd_wdt_auto,
    cmd_help
};

PCHAR OffOnnList[]={"off","on",""};

PCHAR ModeList[]={
	"wdt",         
	"wdt_exp",     
	"bp",          
	"dis_bp",      
	"bp_pwoff",    
	"bp_pwup",     
	"tap",         
	"dis_tap",     
	"tap_pwup",    
	"tx",          
	"std_nic",     
	"wdt_exp_time",
	"bp_previous",
	"tpl",
	"disc",
	"dis_disc",
	"disc_previous",
	"disc_pwup",
	"bp_wait_at_pwup",
	"bp_hw_reset",
	"tap_previous",
	"\0"
};

enum _MODE_LIST { 
	ML_WDT=0,            //  UINT64 wdt_on_off:2;     // 3<<0
	ML_WDT_EXP,          //  UINT64 wdt_exp_bp_tap_disc:2; // 3<<2
	ML_BP,               //  UINT64 bp_on_off:2;      // 3<<4
	ML_DIS_BP,           //  UINT64 bp_dis_on_off:2;  // 3<<6
	ML_BP_PWOFF,         //  UINT64 bp_pwoff_on_off:2;// 3<<8
	ML_BP_PWUP,          //  UINT64 bp_pwup_on_off:2; // 3<<10
	ML_TAP,              //  UINT64 tap_on_off:2;     // 3<<12
	ML_DIS_TAP,          //  UINT64 tap_dis_on_off:2; // 3<<14
	ML_TAP_PWUP,         //  UINT64 tap_pwup_on_off:2;// 3<<16
	ML_TX,               //  UINT64 tx_on_off:2;      // 3<<18
	ML_STD_NIC,          //  UINT64 nic_on_off:2;     // 3<<20
	ML_WDT_EXP_TIME,     //  UINT64 wdt_exp_time:2;   // 3<<22
	ML_bp_previous,      //  UINT64 bp_previous:2;    // 3<<24
	ML_two_port_link,    //  UINT64 two_port_link:2;  // 3<<26
	ML_disc_on_off,      //  UINT64 disc_on_off:2     // 3<<28
	ML_disc_dis_on_off,  //  UINT64 disc_dis_on_off:2 // 3<<30
	ML_disc_previous,    //  UINT64 disc_previous:2   // 3<<32
	ML_disc_pwup_on_off, //  UINT64 disc_pwup_on_off:2// 3<<34
	ML_bp_wait_at_pwup,  //  UINT64 bp_wait_at_pwup:2 // 3<<36
	ML_bp_hw_reset,      //  UINT64 bp_hw_reset:2     // 3<<38
	ML_tap_previous,     //  UINT64 disc_previous:2   // 3<<40
	ML_LAST
};

PCHAR BpCapsList[]={
    "BP_CAP",                       // 0x00000001
    "BP_STATUS_CAP",                // 0x00000002
    "BP_STATUS_CHANGE_CAP",         // 0x00000004
    "SW_CTL_CAP",                   // 0x00000008
    "BP_DIS_CAP",                   // 0x00000010
    "BP_DIS_STATUS_CAP",            // 0x00000020
    "STD_NIC_CAP",                  // 0x00000040
    "BP_PWOFF_ON_CAP",              // 0x00000080
    "BP_PWOFF_OFF_CAP",             // 0x00000100
    "BP_PWOFF_CTL_CAP",             // 0x00000200
    "BP_PWUP_ON_CAP",               // 0x00000400
    "BP_PWUP_OFF_CAP",              // 0x00000800
    "BP_PWUP_CTL_CAP",              // 0x00001000
    "WD_CTL_CAP",                   // 0x00002000
    "WD_STATUS_CAP",                // 0x00004000
    "WD_TIMEOUT_CAP",               // 0x00008000
    "TX_CTL_CAP",                   // 0x00010000
    "TX_STATUS_CAP",                // 0x00020000
    "TAP_CAP",                      // 0x00040000
    "TAP_STATUS_CAP",               // 0x00080000
    "TAP_STATUS_CHANGE_CAP",        // 0x00100000
    "TAP_DIS_CAP",                  // 0x00200000
    "TAP_DIS_STATUS_CAP",           // 0x00400000
    "TAP_PWUP_ON_CAP",              // 0x00800000
    "TAP_PWUP_OFF_CAP",             // 0x01000000
    "TAP_PWUP_CTL_CAP",             // 0x02000000
    "NIC_CAP_NEG",                  // 0x04000000
    "TPL_CAP",                      // 0x08000000
    "DISC_CAP",                     // 0x10000000
    "DISC_DIS_CAP",                 // 0x20000000
    "DISC_PWUP_CTL_CAP",            // 0x40000000
   "Reserved"                       // 0x80000000
};

PCHAR BpCapsExtList[]={
    "TPL2",                   // 0x00000001
    "TX_CTL2",                // 0x00000002
    "Reserved", 					// 0x00000004
    "Reserved", 					// 0x00000008
    "Reserved", 					// 0x00000010
    "Reserved", 					// 0x00000020
    "Reserved", 					// 0x00000040
    "Reserved", 					// 0x00000080
    "Reserved", 					// 0x00000100
    "Reserved", 					// 0x00000200
    "Reserved", 					// 0x00000400
    "Reserved", 					// 0x00000800
    "Reserved", 					// 0x00001000
    "Reserved", 					// 0x00002000
    "Reserved", 					// 0x00004000
    "Reserved", 					// 0x00008000
    "Reserved", 					// 0x00010000
    "Reserved", 					// 0x00020000
    "Reserved", 					// 0x00040000
    "Reserved", 					// 0x00080000
    "Reserved", 					// 0x00100000
    "Reserved", 					// 0x00200000
    "Reserved", 					// 0x00400000
    "Reserved", 					// 0x00800000
    "Reserved", 					// 0x01000000
    "Reserved", 					// 0x02000000
    "Reserved",               // 0x04000000
    "Reserved",               // 0x08000000
    "Reserved", 					// 0x10000000
    "Reserved", 					// 0x20000000
    "Reserved", 					// 0x40000000
    "Reserved",               // 0x80000000
};


int keyword_index(PCHAR *list, PCHAR keyWord){
	int i;
	for(i=0;*list[i];i++) {
		if(!_stricmp(list[i],keyWord)) {
			return i;
		}
	}
	return -1;
}

int GetCmdId(PCHAR keyWord){
	return keyword_index(cmd_list,keyWord)+1;
}

int ModeIndex(PCHAR keyWord){
	return keyword_index(ModeList,keyWord);
}

PCHAR Msg[]={
//0
"Bypass SD test tool ver. " APP_VER " \n"
"Use: " APP_NAME_STR " COMMAND [TARGET] [PARAMETERS] [; comments]\n"
"COMMAND     - install | uninstall | start | stop |\n"
"              rescan | devNum | set | get | wdt | help\n"
"TARGET      - {NIC_GUID} | all | BP_INDEX | help\n"
"  BP_INDEX  - decimal number of bypass device\n"
"  all       - execute COMMAND for all bypass devices\n"
"  help      - get COMMAND parameters list (if supported) \n"
"Command descriptions:\n"
" Global commands (TARGET and PARAMETERS not required)\n"
"help      : print detailed help\n"
"install   : install Bypass SD driver in system\n"
"uninstall : uninstall Bypass SD driver from system \n"
"start     : start Bypass SD driver \n"
"stop      : stop Bypass SD driver \n"
"rescan    : update bypass devices list\n"
"devNum    : return number of Bypass pairs in ERRORLEVEL\n"
"   Commands to bypass device (TARGET required)\n"
"is_bypass\t: print bypass information for NIC.\n"
"get_cap  \t: print bypass device capabilities information.\n"
"get      \t: return bypass device state information \n"
"set      \t: configurate bypass device state \n"
"wdt      \t: configurate bypass device WatchDog timer \n"
"wdt_auto \t: configurate bypass device WatchDog timer for auto reset\n"
"N.B. All keywords are key insensitive. GUIDs must be in UPPERCASE. \n"
//1,"install   : install Bypass SD driver in system\n"
,""
//2,"uninstall : uninstall Bypass SD driver from system \n"
,""
//3,"start     : start Bypass SD driver \n"
,""
//4,"stop      : stop Bypass SD driver \n"
,""
//5,"rescan    : update bypass device list\n"
,""
//6,"devNum    : return number of Bypass pairs in ERRORLEVEL\n"
,""
//7,"is_bypass\t: return bypass information for NIC..\n"
,""
//8 "get_cap  \t: print bypass device capabilities information.\n"
,""
//9
, APP_NAME_STR " set TARGET PARAMETERS\n"
"\t\t  TARGET  is {NIC_GUID} or <bypass Id> or all \n"
"\t\t  PARAMETERS is a set of pairs keyword VALUE \n"
"\tVALUE: 1 | ON | 0 | OFF \n"
"wdt_exp       - set watchdog timer expire mode (bp, tap or disc)\n"
"bp            - set Bypass mode \n"
"dis_bp        - set Disable Bypass mode \n"
"bp_pwoff      - set Bypass mode at power-off state\n"
"bp_pwup       - set Bypass mode at power-up state\n"
"std_nic       - set Standard NIC mode \n"
"tx            - set transmitter state (enabled / disabled)\n"
"tap           - set TAP mode \n"
"dis_tap       - set Disable TAP mode state\n"
"tap_pwup      - set TAP mode at power-up state\n"
"tpl           - set two port link mode\n" 
"disc          - set Disconnect mode \n"   
"dis_disc      - set Disable Disconnect mode \n"
"disc_pwup     - set Disconnect mode at power-up state\n"
"E.G.: " APP_NAME_STR " set all bp off tx 1 \n"
//10
, APP_NAME_STR " get TARGET PARAMETERS\n"
"\t\t  TARGET  is {NIC_GUID} or <bypass Id> or all: \n"
"\t\t  PARAMETERS is a set of keywords: \n"
"bp            - get Bypass mode state\n"
"bp_previous   - return On if device were in Bypass state after last 'get bp' command\n"
"dis_bp        - get Disable Bypass mode state\n"
"bp_pwoff      - get Bypass mode at power-off state\n"
"bp_pwup       - get Bypass mode at power-up state\n"
"std_nic       - get Standard NIC mode settings\n"
"wdt           - get watchdog state\n"
"wdt_exp_time  - get watchdog expired time\n"
"tx            - get transmitter state (enabled / disabled)\n"
"tap           - get TAP mode state\n"
"dis_tap       - get Disable TAP mode state\n"
"tap_pwup      - get TAP mode at power-up state\n"
"wdt_exp       - get adapter state when WDT expired (Bypass, TAP or Disconnect)\n"
"tpl           - get two port link mode\n"    
"disc          - get Disconnect mode \n"   
"dis_disc      - get Disable Disconnect mode \n"
"disc_pwup     - get Disconnect mode at power-up state\n"
"tap_previous  - return On if device were in Tap state after last 'get tap' command\n"
"disc_previous - return On if device were in Disconnect state after last 'get disc' command\n"
"E.G.: " APP_NAME_STR " get 0 bp tx \n"
//11
, APP_NAME_STR " wdt TARGET PARAMETERS\n"
"\t\t  TARGET  is {NIC_GUID} or <bypass Id> or all: \n"
"\t\t  PARAMETER can be: \n"
"\t off     - disable WatchDog timer \n"
"\t reset   - restart WatchDog timer \n"
"\t VALUE   - set WatchDog timout for VALUE miliseconds (0-disable, the same as off) \n"
"E.G.: " APP_NAME_STR " wdt all 2000\n"
"\t Set WDT to 2sec timeout for all bypass devices\n"
//12
, APP_NAME_STR " wdt_auto TARGET PARAMETERS\n"
"\t\t  TARGET  is {NIC_GUID} or <bypass Id> or all: \n"
"\t\t  PARAMETER can be: \n"
"\t get     - return WatchDog  auto reset timer value\n"
"\t off     - disable WatchDog auto reset \n"
"\t VALUE   - set WatchDog auto reset timout for VALUE miliseconds (0-disable, the same as off) \n"
"E.G.: " APP_NAME_STR " wdt_auto all 1000\n"
"\t Set WDT auto reset to 1sec timeout for all bypass devices\n"
//13
// End of help
,"\xFFHELP_END"
};



VOID DoHelp(UINT32 msgNum, PVOID param){
	if(NULL==param) printf(Msg[msgNum]);
	else printf(Msg[msgNum],param);
}

BOOL NeedHelp(char *kw, UINT32 hIndex ){
	if(_stricmp("help",kw)) return FALSE;
	if(*Msg[hIndex])DoHelp(hIndex,0);
	else printf("Parameters not needed for this command.\n");
	return TRUE;
}

VOID AllHelp(){
	int i;
	for ( i=0;*Msg[i]!='\xFF';i++) {
		if(*Msg[i])DoHelp(i,0);
	}
}


BOOL WINAPI DoInfInstall()
{
	BOOL 	ret;
	HINF 	hinf;
	PCHAR	InfName = ".\\bpsddrv.inf";
	PCHAR	InstallSectionName = "DefaultInstall.NT";
	PCHAR	ServiceSectionName = "DefaultInstall.NT.Services";
	void *callback_context;

	hinf = SetupOpenInfFileA(InfName, NULL, INF_STYLE_WIN4, NULL);
	if (hinf == INVALID_HANDLE_VALUE) {
		TRACE_ERR(("Cannot open inf file %s\n", InfName));
		return FALSE;
	}

	callback_context = SetupInitDefaultQueueCallback(NULL);

	ret = SetupInstallFromInfSectionA(NULL, hinf, InstallSectionName, SPINST_FILES,
//				NULL, NULL, SP_COPY_NEWER_OR_SAME | SP_COPY_NOSKIP, SetupDefaultQueueCallbackA,
				NULL, NULL, SP_COPY_NEWER_OR_SAME, SetupDefaultQueueCallbackA,
				callback_context, NULL, NULL);
//	ret = SetupInstallFromInfSectionA(NULL, hinf, InstallSectionName, SPINST_ALL,
//				NULL, NULL, 0, SetupDefaultQueueCallbackA,
//				callback_context, NULL, NULL);
	if (!ret) {
		TRACE_ERR(("Cannot install from inf file %s, section %s, error %d\n", InfName, InstallSectionName, GetLastError()));
	}
	else {
		ret = SetupInstallServicesFromInfSectionA(hinf, ServiceSectionName, SPSVCINST_TAGTOFRONT);
		if (!ret) {
			TRACE_ERR(("Cannot install from inf file %s, section %s, error %d\n", InfName, ServiceSectionName, GetLastError()));
		}
	}

	SetupTermDefaultQueueCallback(callback_context);
	SetupCloseInfFile(hinf);

	return ret;
}

UINT32 DoSetup(UINT32 cmdId){
	UINT32		ret=0;
	SC_HANDLE	schSCManager;
	schSCManager = OpenSCManager (NULL,NULL,SC_MANAGER_ALL_ACCESS);

	switch(cmdId){
		case cmd_install : 
			ret=DoInfInstall();
//			ret=InstallDriver (schSCManager,SERVICE_NAME,DRIVER_SYS_PATH);
			break;
		case cmd_uninstall : 
			if(hBPDevice == INVALID_HANDLE_VALUE) {
				hBPDevice=OpenBpDevice(1);
			}
			if(hBPDevice != INVALID_HANDLE_VALUE) {
				CloseBpDevice();
				ret=1;
				TRACE_ERR(("Driver is started. Stop driver before running uninstall command.\n"));
			}
			else {
				ret=RemoveDriver (schSCManager,SERVICE_NAME);
			}
			break;
		case cmd_start :
			ret=StartDriver (schSCManager,SERVICE_NAME);
			break;
		case cmd_stop :
			ret=StopDriver (schSCManager,SERVICE_NAME);
			break;
		default:
			TRACE_ERR(("Invalid setup command %d\n",cmdId));
	}
	CloseServiceHandle (schSCManager);
	return ret?0:1;
} 

UINT32 GetDevNum(){
	if(BYPASS_CALL(BP_CMD_GET_NUM,hBPDevice,&bpCmd,&bpCmdState)) return bpCmdState.BpDeviceIndex;
	return 0;
}

int ParseTarget(char *target,UINT32 *first,UINT32 *last, UINT32 *all){
	int	i,l;

	*all = 0;
	if('{'==*target) {
		l=strlen(target);
		if( (l!=GUID_STR_LEN) || ('}'!=target[GUID_STR_LEN-1]) ){
			PRINTF((" Invalid GUID str  \"%s\" \n",target)); 
			return -2;
		}
		COPY_GUID_STR(bpCmd.NicGuidStr,target);

		bpCmd.Command=BP_CMD_IS_BYPASS;
		i=BPIO_CTRL(hBPDevice,&bpCmd,&bpCmdState);
		if(!i) return -2;

		switch(bpCmdState.Status ) {
			case BP_STATUS_MASTER :  
				PRINTF((" \"%s\" is master Bypass device bpId=%d\n",target,bpCmdState.BpDeviceIndex)); 
				return *first=*last=bpCmdState.BpDeviceIndex;
			case BP_STATUS_SLAVE :  
				PRINTF((" \"%s\" is slave Bypass device bpId=%d\n",target,bpCmdState.BpDeviceIndex)); 
//				return *first=*last=bpCmdState.BpDeviceIndex;
				return -2;
			default:  
				PRINTF((" \"%s\" not Bypass device\n",target)); 
				return -2;
		}
	} else if(!_stricmp("all",target)) {
		*all=1;
		*first=0;
		*last=GetDevNum();
		if(!*last){
			PRINTF(("No Bypass devices\n")); 
			return -2;
		} else {
			--(*last);
		}
		return -1;
	} else if((*target >='0') && (*target <='9') ){
		return *first=*last=atoi(target);
	} else {
		PRINTF((" Invalid TARGET  \"%s\" \n",target)); 
		return -2;
	}
}


BOOLEAN GetConnectionName(IN char *pGuidStr,OUT char *pConnectionName,UINT32 buffSize){
#define CONNECTIONS_KEY  "SYSTEM\\CurrentControlSet\\Control\\Network\\{4D36E972-E325-11CE-BFC1-08002BE10318}\\"
#define CONNECTION_KEY "\\Connection"
	char	pKey[512];
	LONG	lRet;
	HKEY	hKey = INVALID_HANDLE_VALUE;
	DWORD	dwBufLen=sizeof(pKey);

	strcpy(pKey,CONNECTIONS_KEY);
	strcat(pKey,pGuidStr);
	strcat(pKey,CONNECTION_KEY);

	lRet = RegOpenKeyEx( HKEY_LOCAL_MACHINE,pKey,0, KEY_QUERY_VALUE, &hKey);
	if( lRet != ERROR_SUCCESS ) return FALSE;
	lRet = RegQueryValueEx( hKey, "Name", NULL, NULL,(LPBYTE) pConnectionName, &dwBufLen);
	RegCloseKey( hKey );
	if(lRet != ERROR_SUCCESS)  return FALSE;
	pConnectionName[dwBufLen] =0;
	return TRUE;
}

UINT32 DoIsBypass(int argc,char *argv[]){
	UINT32	ret=Err_OK,r1,j;
	PUCHAR	Target=argv[2];
	int		tgId,i,bpIdFirst=0,bpIdLast=-1;
	int		DeviceIndex;
	UINT32	AllTgFlag;

	if(argc!=3){
		PRINTF((" Invalid number of parameters \n")); 
		return Err_Parameters;
	}

	tgId=ParseTarget(Target,&bpIdFirst,&bpIdLast, &AllTgFlag);
	if(-2==tgId){
		return Err_Parameters;
	}
	if('{'==*Target) return ret;

	bpCmd.Command=BP_CMD_GET_DEVICE_INFO;

	for(i = DeviceIndex = bpIdFirst; i<=bpIdLast; i++, DeviceIndex++){
		bpCmdState.Status = 0;
		bpCmd.BpDeviceIndex = DeviceIndex;
		bpCmd.Command=BP_CMD_GET_DEVICE_INFO;
		PRINTF(("\nGET_BYPASS_DEVICE_INFO for bpId=%d\n",DeviceIndex));
		for( j=0;j<2;j++) {
			bpCmd.params.flags.value = (UINT64) j;
			if(BPIO_CTRL(hBPDevice,&bpCmd,&bpCmdState)){
				if(BP_STATUS_UNKNOWN==bpCmdState.Status){
					PRINTF(("\tUNKNOWN device\n"));
					ret=Err_Parameters;
					break;
				} else if(BP_STATUS_NOT_CONNECTED==bpCmdState.Status){
					PRINTF(("\tDevice not inserted\n"));
					if(AllTgFlag) {
						i--;
					}
					break;
				} else {
					UINT32 bus=BP_BUS_FROM_STATUS(bpCmdState.Status);
					UINT32 dev=BP_DEV_FROM_STATUS(bpCmdState.Status);
					UINT32 func=BP_FUN_FROM_STATUS(bpCmdState.Status);
					char GuidStr[GUID_STR_LEN+1];
					char ConnectionName[512];

					COPY_GUID_STR(GuidStr,bpCmdState.NicGuidStr)
					GuidStr[GUID_STR_LEN]=0;

					PRINTF(("GUID=\"%s\" %s \n",GuidStr,(j?"Slave":"Master"))); 
					PRINTF(("\tPCI info Bus=%d Device=%d Function=%d\n",bus,dev,func)); 
					if(GetConnectionName(GuidStr,ConnectionName,sizeof(ConnectionName))){
						PRINTF(("\tConnection '%s'\n",ConnectionName)); 
					}
					if(!BP_STATUS_CONNECTED(bpCmdState.Status)){
						PRINTF(("\tNdis driver not started\n"));
					}

				}
			}
		}
	}
	return ret;
}


VOID    PrintWDTCap(BYPASS_CMD_STATE *pbpCmdState){
	UINT32	wdt_cap = pbpCmdState->params.wdt_cap;
	if(wdt_cap) {
		PRINTF(("WDT_MIN_TIME=%d*100 ms WDT_STEP_TIME=%d WDT_STEP_COUNT=%d\n",
			WD_MIN_TIME_GET(wdt_cap),
			WDT_STEP_TIME_GET(wdt_cap),
			WD_STEP_COUNT_GET(wdt_cap)  
		)); 
	}
}

VOID    PrintBPCap(BYPASS_CMD_STATE *pbpCmdState){
    int i,len = sizeof(BpCapsList)/sizeof(*BpCapsList);
    UINT32 bp_cap     = pbpCmdState->params.bp_cap;
    UINT32 bp_cap_ext = pbpCmdState->params.bp_cap_ext;
    
    PRINTF(("Bypass capabilities: \n")); 
    for(i=0;i<len;i++,bp_cap>>=1){
        if(1 & bp_cap ){
           PRINTF(("\t%s\n",BpCapsList[i])); 
        }
    }
	if(bp_cap_ext) {
       PRINTF(("Bypass extended capabilities: \n")); 
       for(i=0;i<len;i++,bp_cap_ext>>=1){
           if(1 & bp_cap_ext ){
              PRINTF(("\t%s\n",BpCapsExtList[i])); 
           }
       }
	}
}

VOID    PrintCmdStatusFlags(BYPASS_CMD_STATE *pbpCmdState){
	int			i;
	static char *stateStr[]={"UNDEFINED","ON","OFF","UNSUPPORTED"};
	UINT64 		flag,flags=pbpCmdState->params.flags.value;

	for ( i=0;i<ML_LAST;i++,flags>>=2) {
		flag=0x3&flags;
		if(flag){
			switch(i){
				case  ML_WDT:     
					if(flag == BP_CMD_ON){
						if(-1==pbpCmdState->params.timeout_ms){
							PRINTF((" %s - wdt state is unknown \n",ModeList[i])); 
						} else {  
							PRINTF((" %s is %s timeout is %d ms \n",ModeList[i],stateStr[flag],pbpCmdState->params.timeout_ms)); 
						}
						flag=0;
					}
					break;
				case  ML_WDT_EXP_TIME:
					if(flag == BP_CMD_ON){
						if(-1==pbpCmdState->params.exp_time_ms){ 
							PRINTF((" %s - wdt state is unknown \n",ModeList[i])); 
						} else if(0==pbpCmdState->params.exp_time_ms){ 
							PRINTF((" %s - wdt has expired \n",ModeList[i])); 
						} else {
							PRINTF((" %s is %s time is %d ms \n",ModeList[i],stateStr[flag],pbpCmdState->params.exp_time_ms)); 
						}
						flag=0;
					}
					break;
				case  ML_WDT_EXP:
					PRINTF((" %s is %s \n",ModeList[i],
						((flag == MODE_DISCONNECT) ? "DISCONNECT" : 
						(flag == MODE_BYPASS)     ? "BYPASS" : 
						(flag == MODE_TAP)        ? "TAP" : "UNSUPPORTED"))); 
					flag=0;
					break;
			}
			if(flag){
				PRINTF((" %s is %s \n",ModeList[i],stateStr[flag])); 
			}
		}
	}
}

VOID PrintSetGetCap(BYPASS_CMD_STATE *pbpCmdState){
	int				i;
	static char 	*stateStr[]={"UNSUPPORTED","    Get","Set","Set Get"};
	UINT64 			flag,flags=pbpCmdState->params.flags.value;
	PRINTF(("Set/Get valid parameters:\n")); 

	for ( i = 0;i < ML_LAST;i++, flags >>= 2) {                  
		flag=0x3&flags;                                            
		if(flag && i != ML_bp_wait_at_pwup && i != ML_bp_hw_reset){
			PRINTF(("\t %15.15s: %s \n",ModeList[i],stateStr[flag])); 
		}
	}

}

VOID PrintBpCmdStatus(BPSTATUS Status){
    char *txt="Failed. ";
    switch(Status){
        case  BP_STATUS_UNKNOWN			: txt="Invalid target device. ";break;   
        case  BP_STATUS_UNSUPPORTED		: txt="Command is UNSUPPORTED. ";break;   
        case  BP_STATUS_DRIVER_BUSY		: txt="Driver busy. ";break;   
        case  BP_STATUS_DEVICE_BUSY		: txt="Device busy. ";break;   
        case  BP_STATUS_INTERNAL_ERROR	: txt="Internal error. ";break;   
        case  BP_STATUS_TPL_ENABLED		: txt="Device cannot process command because TPL mode is set. ";break;   
        case  BP_STATUS_NOT_CONNECTED	: txt="Device not inserted or NDIS driver not started. ";break;   
		default:
			PRINTF(("Command failed, device return Status=0x%X\n",Status)); 
			return;
    }
    PRINTF(("%s \n",txt)); 
}

UINT32 DoGetCap(IN int   argc,IN char *argv[] ){
	UINT32	ret=Err_OK,r1,j;
	PUCHAR	Target=argv[2];
	char	*NamesList[]=Bypass_Device_List;
	int		tgId,i,bpIdFirst=0,bpIdLast=-1;
	int		DeviceIndex;
	UINT32	AllTgFlag;

	if(argc<3){
		PRINTF((" Invalid number of parameters \n")); 
		return Err_Parameters;
	}

	tgId=ParseTarget(Target,&bpIdFirst,&bpIdLast, &AllTgFlag);
	if(-2==tgId){
		return Err_Parameters;
	}

	bpCmd.Command=BP_CMD_GET_CAP;
	bpCmd.params.flags.value = 0;
	for(i = DeviceIndex = bpIdFirst; i<=bpIdLast; i++, DeviceIndex++){
		bpCmdState.params.flags.value = 0;
		bpCmdState.Status = 0;
		bpCmd.BpDeviceIndex = DeviceIndex;
		PRINTF(("\nBP_CMD_GET_CAP for bpId=%d\n",DeviceIndex));
		r1=BYPASS_CALL(BP_CMD_GET_CAP,hBPDevice,&bpCmd,&bpCmdState);
		if(r1){
			if(BP_STATUS_OK==bpCmdState.Status) {
				PRINTF((" %s\n",NamesList[bpCmdState.params.pb_dev_type]));
				PrintBPCap(&bpCmdState);
				PrintWDTCap(&bpCmdState);
				PrintSetGetCap(&bpCmdState);
			} else if(BP_STATUS_NOT_CONNECTED==bpCmdState.Status){
				PRINTF(("\tDevice not inserted\n"));
				if(AllTgFlag) {
					i--;
				}
			} else {
				PrintBpCmdStatus(bpCmdState.Status); 
				ret=Err_Parameters;
			}
		} else {
			PRINTF(("Request to Device Failed.\n")); 
			ret=Err_Driver;
		}
	}

	return ret;
}

UINT32 DoGetCmd(IN int   argc,IN char *argv[] ){
	UINT32	ret=Err_OK,r1,j;
	PUCHAR	Target=argv[2];
	int		tgId,i,bpIdFirst=0,bpIdLast=-1;
	int		DeviceIndex;
	UINT32	AllTgFlag;

	if(argc<4){
		PRINTF((" Invalid number of parameters \n")); 
		return Err_Parameters;
	}
	tgId=ParseTarget(Target,&bpIdFirst,&bpIdLast, &AllTgFlag);
	if(-2==tgId){
		return Err_Parameters;
	}

	bpCmd.Command=BP_CMD_GET_STATE;
	bpCmd.params.flags.value = 0;
	if(!_stricmp("all",argv[3])){
		bpCmd.params.flags.value = BP_CMD_GET_MASK & ~(BP_CMD_MASK_BP_WAIT_AT_PWUP | BP_CMD_MASK_BP_HW_RESET);
	} else for(i=3;(i<argc);i++){
		j=ModeIndex(argv[i]);
		if(-1==j){
			PRINTF(("Invalid parameter \"%s\" \n",argv[i])); 
			return Err_Parameters;
		}
		bpCmd.params.flags.value |= ((UINT64)(BP_CMD_GET)<<(j*2));
	}
	for(i = DeviceIndex = bpIdFirst; i<=bpIdLast; i++, DeviceIndex++){
		bpCmdState.params.flags.value = 0;
		bpCmdState.Status = 0;
		bpCmd.BpDeviceIndex = DeviceIndex;
		PRINTF(("\nBP_CMD_GET_STATE for bpId=%d\n",DeviceIndex));
		r1=BYPASS_CALL(BP_CMD_GET_STATE,hBPDevice,&bpCmd,&bpCmdState);
		if(r1){
			if(BP_STATUS_OK==bpCmdState.Status) {
				PrintCmdStatusFlags(&bpCmdState);
			} else if(BP_STATUS_NOT_CONNECTED==bpCmdState.Status){
				PRINTF(("\tDevice not inserted\n"));
				if(AllTgFlag) {
					i--;
				}
			} else {
				PrintBpCmdStatus(bpCmdState.Status); 
				ret=Err_Parameters;
			}
		} else {
			PRINTF(("Request to Device Failed.\n")); 
			ret=Err_Driver;
		}
	}

	return ret;
};

int TestSetMode(int mode) { 
    switch(mode){
       case ML_WDT :              case ML_BP :             case ML_DIS_BP : 
       case ML_BP_PWOFF :         case ML_BP_PWUP :        case ML_TAP : 
       case ML_DIS_TAP :          case ML_TAP_PWUP :       case ML_TX : 
       case ML_STD_NIC :          case ML_two_port_link:
       case ML_disc_on_off :      case ML_disc_dis_on_off : 
       case ML_disc_pwup_on_off : case ML_bp_wait_at_pwup : 
       case ML_bp_hw_reset :      case ML_WDT_EXP:
          return 1;
       default: return 0;
   }
}

int GetParamValue(char *str) { 
    int val=-1;
    if(!_stricmp("on",str)) val=1;
    else if(!_stricmp("off",str)) val=0;
    else if((*str>='0') &&(*str<='9')){
        val=atoi(str);        
    } 
    return val;
}

int GetExpiredModeParamValue(char *str) { 
    int val=-1;
    if(!_stricmp("bp",str))			val = MODE_BYPASS;
    else if(!_stricmp("tap",str))	val = MODE_TAP;
    else if(!_stricmp("disc",str))	val = MODE_DISCONNECT;
    return val;
}

UINT32 DoSetCmd(IN int   argc,IN char *argv[] ){
	UINT32	ret=Err_OK,r1,j;
	PUCHAR	Target=argv[2];
	int		tgId,i,bpIdFirst=0,bpIdLast=-1;
	int		DeviceIndex;
	UINT32	AllTgFlag;
	
	if( (argc<5) || (0==(1&argc)) ){
		PRINTF((" Invalid number of parameters \n")); 
		return Err_Parameters;
	}

	tgId=ParseTarget(Target,&bpIdFirst,&bpIdLast, &AllTgFlag);
	if(-2==tgId){
		return Err_Parameters;
	}

	bpCmd.Command=BP_CMD_GET_STATE;
	bpCmd.params.flags.value = 0;
	for(i=3;(i<argc);i+=2){
		UINT32 val;  
//		UINT64 Cmd;
		j=ModeIndex(argv[i]);
		if(!TestSetMode(j)){
			PRINTF(("Invalid parameter %d \"%s\" \n",(i-2),argv[i])); 
			return Err_Parameters;
		}

		if((i+1)==argc){
			PRINTF(("Invalid number of parameters\n")); 
			return Err_Parameters;
		}

		if(j == ML_WDT_EXP) {
			val = GetExpiredModeParamValue(argv[i+1]);
		}
		else {
			val = GetParamValue(argv[i+1]);
		}
		if(-1 == val){
			PRINTF(("Invalid parameter %d \"%s\" value \"%s\" \n",(i-2),argv[i],argv[i+1])); 
			return Err_Parameters;
		}
		bpCmd.params.flags.value |= ((UINT64) (val ? BP_CMD_ON:BP_CMD_OFF))<<(j*2);
		switch(j) {
			case ML_WDT:
				bpCmd.params.timeout_ms=val;
				break;
			case ML_WDT_EXP:
				bpCmd.params.wdt_exp_mode=val;
				break;
		}
	}
	for(i = DeviceIndex = bpIdFirst; i<=bpIdLast; i++, DeviceIndex++){
		bpCmd.BpDeviceIndex = DeviceIndex;
		PRINTF(("\nBP_CMD_SET_STATE for bpId=%d\n",DeviceIndex));
		r1=BYPASS_CALL(BP_CMD_SET_STATE,hBPDevice,&bpCmd,&bpCmdState);
		if(r1){
			if(BP_STATUS_OK==bpCmdState.Status) {
				PrintCmdStatusFlags(&bpCmdState);
			} else if(BP_STATUS_NOT_CONNECTED==bpCmdState.Status){
				PRINTF(("\tDevice not inserted\n"));
				if(AllTgFlag) {
					i--;
				}
			} else {
				PrintBpCmdStatus(bpCmdState.Status); 
				ret=Err_Parameters;
			}
		} else {
			PRINTF(("Request to Device Failed.\n")); 
			ret=Err_Driver;
		}
	}

	return ret;
};

UINT32 DoWdtCmd(IN int   argc,IN char *argv[] ){
	UINT32	ret=Err_OK,r1,j;
	PUCHAR	Target=argv[2];
	int		tgId,i,bpIdFirst=0,bpIdLast=-1,val=-1;
	int		DeviceIndex;
	UINT32	AllTgFlag;

	if(argc<4){
		PRINTF((" Invalid number of parameters \n")); 
		return Err_Parameters;
	}
	tgId=ParseTarget(Target,&bpIdFirst,&bpIdLast, &AllTgFlag);
	if(-2==tgId){
		return Err_Parameters;
	}

	bpCmd.params.flags.value = 0;
	{ 
		char *str=argv[3];
		if(!_stricmp("reset",str)){
			val=-1;
			bpCmd.Command = BP_CMD_RESET_WDT;
		} else {
			if(!_stricmp("off",str)){
				val=0;
			} else if((*str>='0') &&(*str<='9')){
				val = atoi(str);        
				bpCmd.params.timeout_ms = val;
			} else {
				PRINTF((" Invalid parameter \"%s\" \n",str)); 
				return Err_Parameters;
			}
			bpCmd.Command = BP_CMD_SET_STATE;
			bpCmd.params.flags.value = FL_WDT_ON_OFF(val?BP_CMD_ON:BP_CMD_OFF);
		}
	}

	for(i = DeviceIndex = bpIdFirst; i<=bpIdLast; i++, DeviceIndex++){
		bpCmdState.params.flags.value = 0;
		bpCmdState.Status = 0;
		bpCmd.BpDeviceIndex = DeviceIndex;
		PRINTF(("\nBP_CMD_WDT  for bpId=%d \n",DeviceIndex));
		r1=BPIO_CTRL(hBPDevice,&bpCmd,&bpCmdState);
		if(r1){
			if(BP_STATUS_OK==bpCmdState.Status) {
				if(-1==val){
					PRINTF(("WDT restarted \n")); 
				} else if(val){
					PRINTF(("WDT timeout set to %d \n",bpCmdState.params.timeout_ms)); 
				} else {
					PRINTF(("WDT disabled \n")); 
				}
			} else if(BP_STATUS_NOT_CONNECTED==bpCmdState.Status){
				PRINTF(("\tDevice not inserted\n"));
				if(AllTgFlag) {
					i--;
				}
			} else {
				PRINTF(("Request to Device Failed.\n")); 
				ret=Err_Parameters;
			}
		} else {
			PRINTF(("Request to Device Failed.\n")); 
			ret=Err_Driver;
		}
	}

	return ret;
}

UINT32 DoWdtAutoCmd(IN int   argc,IN char *argv[] ){
	UINT32	ret=Err_OK,r1,j;
	PUCHAR	Target=argv[2];
	int		tgId,i,bpIdFirst=0,bpIdLast=-1,val=-1;
	int		DeviceIndex;
	UINT32	AllTgFlag;

	if(argc<4){
		PRINTF((" Invalid number of parameters \n")); 
		return Err_Parameters;
	}
	tgId=ParseTarget(Target,&bpIdFirst,&bpIdLast, &AllTgFlag);
	if(-2==tgId){
		return Err_Parameters;
	}

	bpCmd.params.flags.value = 0;
	{ 
		char *str=argv[3];
		if(!_stricmp("get",str)){
			val=-1;
			bpCmd.Command=BP_CMD_GET_AUTO_WDT;
		} else {
			if(!_stricmp("off",str)){
				val=0;
			} else if((*str>='0') &&(*str<='9')){
				val=atoi(str);        
				bpCmd.params.timeout_ms=val;
			} else {
				PRINTF((" Invalid parameter \"%s\" \n",str)); 
				return Err_Parameters;
			}
			bpCmd.Command=BP_CMD_SET_AUTO_WDT;
		}
	}

	for(i = DeviceIndex = bpIdFirst; i<=bpIdLast; i++, DeviceIndex++){
		bpCmdState.params.flags.value = 0;
		bpCmdState.Status = 0;
		bpCmd.BpDeviceIndex = DeviceIndex;
		PRINTF(("\nBP_CMD_WDT  for bpId=%d \n",DeviceIndex));
		r1=BPIO_CTRL(hBPDevice,&bpCmd,&bpCmdState);
		if(r1){
			if(BP_STATUS_OK==bpCmdState.Status) {
				if(-1==val){
					PRINTF(("WDT_AUTO timeout is %d \n",bpCmdState.params.timeout_ms)); 
				} else if(val){
					PRINTF(("WDT_AUTO timeout set to %d \n",bpCmdState.params.timeout_ms)); 
				} else {
					PRINTF(("WDT_AUTO disabled \n")); 
				}
			} else if(BP_STATUS_NOT_CONNECTED==bpCmdState.Status){
				PRINTF(("\tDevice not inserted\n"));
				if(AllTgFlag) {
					i--;
				}
			} else {
				PRINTF(("Request to Device Failed.\n")); 
				ret=Err_Parameters;
			}
		} else {
			PRINTF(("Request to Device Failed.\n")); 
			ret=Err_Driver;
		}
	}

	return ret;
}


UINT32 DoRescan(){
	UINT32	ret;

	ret=BYPASS_CALL(BP_CMD_RESCAN,hBPDevice,&bpCmd,&bpCmdState);
	if(!ret){
		PRINTF(("Bypass IOCTRL failed.\n"));
		return Err_Driver;      
	}
	if(BP_STATUS_OK==bpCmdState.Status){
		PRINTF(("Bypass Rescan finished.\n"));
		if(bpCmdState.BpDeviceIndex){
			PRINTF((" %d Bypass/TAP pairs is installed.\n",bpCmdState.BpDeviceIndex)); 
		} else {
			PRINTF(("No Bypass/TAP pairs is installed.\n")); 
		}
		return Err_OK;
	} else {
		PRINTF(("Bypass Rescan failed.\n"));
		return Err_Rescan;
	}
};


UINT32 DoDevNum(){
	UINT32	ret;
	ret=GetDevNum();
	if(ret){
		PRINTF((" %d Bypass/TAP pairs is installed.\n",ret)); 
	} else {
		PRINTF(("No Bypass/TAP pairs is installed.\n")); 
	}
	return ret;
};

#if DBG
VOID PrintCmdLine(IN int   argc,IN char *argv[] ){
	int	i;
	for(i=0;i<argc;i++){
		TRACE_MSG(("%s ",argv[i]));
	} 
	TRACE_MSG(("\n"));
}

#else
#define PrintCmdLine(a,b)
#endif

UINT32 __cdecl main(IN int   argc,IN char *argv[] ){
	UINT32	cmd_i,errorlevel=Err_OK;
	int		i;

	PrintCmdLine(argc,argv);
	for(i=1;i<argc;i++){ if (*argv[i] == ';') argc=i; }

	if ((argc <2)|| !( cmd_i=GetCmdId(argv[1])) ) {
		DoHelp(0,0);
		return Err_Help;
	}
	if(cmd_help==cmd_i) {
		AllHelp(); 
		return Err_Help;
	}
	if( argc>2 ) if(NeedHelp(argv[2],cmd_i)) return Err_Help;

	if(cmd_i<=cmd_stop){
		errorlevel=(DoSetup(cmd_i)?Err_Setup:0);    
	} else {
		switch ( cmd_i) {
			case  cmd_rescan    : errorlevel=DoRescan();  break;
			case  cmd_devNum    : errorlevel=DoDevNum();  break;
			case  cmd_is_bypass : errorlevel=DoIsBypass(argc,argv);  break;
			case  cmd_get_cap   : errorlevel=DoGetCap(argc,argv);  break;
			case  cmd_get       : errorlevel=DoGetCmd(argc,argv);  break;
			case  cmd_set       : errorlevel=DoSetCmd(argc,argv);  break;
			case  cmd_wdt       : errorlevel=DoWdtCmd(argc,argv);  break;
			case  cmd_wdt_auto  : errorlevel=DoWdtAutoCmd(argc,argv);  break;
			default: 
				PRINTF(("Invalid setup command \"%s\"\n",argv[1]));
				errorlevel=Err_Parameters;
		}
		CloseBpDevice();
	}
	PRINTF(("Complete Errorlevel=%i\n",errorlevel));

	return errorlevel;
}

