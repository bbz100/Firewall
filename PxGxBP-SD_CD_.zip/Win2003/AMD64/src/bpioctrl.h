/*******************************************
Silicom Bypass SD Gigabit Ethernet Adapter
API Version 1.6.0.7 10/21/2012

(C)  Silicom, Ltd. 2010
********************************************/

#ifndef BP_IOCTL_H
#define BP_IOCTL_H   

#define BP_API_VER       0x03000604   

#define DRIVER_NAME         "BPSDDrv.sys" 


#define DEVICE_NAME         "BPSDDev"
#define L_DEVICE_NAME       L"BPSDDev"

#define SERVICE_NAME        "BPSDSrv"
#define L_SERVICE_NAME      L"BPSDSrv"

#define NT_DEVICE_NAME      "\\Device\\"    DEVICE_NAME
#define DOS_DEVICE_NAME     "\\DosDevices\\" DEVICE_NAME

#define L_NT_DEVICE_NAME    L"\\Device\\" L_DEVICE_NAME
#define L_DOS_DEVICE_NAME   L"\\DosDevices\\" L_DEVICE_NAME


#define GUID_NETWORK_ADAPTERS L"{4D36E972-E325-11CE-BFC1-08002BE10318}"
#define GUID_BYBASS_ADAPTERS  L"{2F9B7CA7-F86D-4bf3-8577-F0C4E71DFC08}"
#define BYPASS_PREF L"BP_"
#define GUID_STR_LEN  38
typedef char GUID_CHAR;
typedef GUID_CHAR  GUID_STR[GUID_STR_LEN];
#define COPY_GUID_STR(dest,src) { int i_COPY_GUID_STR; for(i_COPY_GUID_STR=0;i_COPY_GUID_STR<GUID_STR_LEN;i_COPY_GUID_STR++) (dest)[i_COPY_GUID_STR]= (char)(src)[i_COPY_GUID_STR];}

// Bypass API
#define BYPASS_IOCTL_BAZE  0x800
#define BYPASS_DEVICE_TYPE  FILE_DEVICE_UNKNOWN

#define BYPASS_IOCTRL_CMD       CTL_CODE(BYPASS_DEVICE_TYPE,(BYPASS_IOCTL_BAZE+0),METHOD_BUFFERED, FILE_ANY_ACCESS )

// Suported Bypass/TAP devices
#define Bypass_Device_List  { \
"PXG2BPFI-SD",\
"PXG2BPFILX-SD",\
"PXG2BPI-SD",\
"PXG2BPIG-SD",\
"PXG2TBFI-SD",\
"PXG4BPI-SD",\
"PXG4BPFI-SD",\
"PXG4BPFI-LX-SD",\
"PXG2BPFIL-SD",\
"PXG2BPFILLX-SD",\
"PEXG4BPI-SD",\
"PEG2BPI-SD", \
"PEG4BPI-SD", \
"PEG2BPFI-SD", \
"PEG2BPFI-LX-SD", \
"PMCX2BPFI-SD", \
"PMCX2BPFI-N-SD", \
"PMCX2BPI-N-SD", \
"PMCX4BPI-N-SD", \
"PMCX2BPI-N2-SD", \
"PMCX2BPI-SD", \
"PMCX4BPI-N2-SD", \
"PMCX4BPI-SD", \
"PXG2BISC1-SD", \
"PEG2TBFI-SD", \
"PXG2TBI-SD",  \
"PEG4BPFI-SD", \
"PXG4BPFID-SD", \
"PEG4BPIPT-SD", \
"PXG6BPI-SD", \
"PEG4BPIL-SD", \
"PEG2BPFID-SD", \
"MEG2BPFILN-SD", \
"MEG2BPFINX-SD", \
"PEG4BPFILX-SD", \
"PEG2BPIX1-SD", \
"MEG2BPFILXLN-SD", \
"PEG2BPFIDLX-SD", \
"MEG2BPFILXNX-SD", \
"PE10G2BPICX4-SD", \
"PE10G2BPISR-SD", \
"PE10G2BPILR-SD", \
"MHIO8-AD", \
"MHIO8-AD", \
"PEG4BPFI5-SD", \
"PEG4BPFI5-SD", \
"PEG4BPFI5LX-SD", \
"PEG4BPFI5LX-SD", \
"MEG4BPFIJP-SD", \
"ME10G2BPISRJP-SD", \
"PEG2BPID-SD", \
"PEG6BPI-SD", \
"MEG4BPIJP-SD", \
"XE10G2BPICX4-SD", \
"XE10G2BPISR-SD", \
"XE10G2BPISR-SD-N", \
"XE10G2BPILR-SD", \
"PEG2BISC6-SD", \
"PEG6BPIFC-SD", \
"PXE2TBI-SD", \
"PXE2TAPI-SD", \
"PE210G2BPI9SR-SD", \
"PE210G2BPI9LR-SD", \
"PEG2BPFI5-SD", \
"PEG2BPFI5LX-SD", \
"PEG2BPFI6-SD", \
"PEG2BPFI6LX-SD", \
"PEG2BPFI6ZX-SD", \
"PEG4BPFI6-SD", \
"PEG4BPFI6LX-SD", \
"PEG4BPFI6ZX-SD", \
"PXEG4BPFI-SD", \
"PEG2BPI6-SD", \
"PEG4BPI6-SD", \
"PEG6BPI6-SD", \
"PEG2BPI6SC6-SD", \
"PE2G4BPI80L-SD", \
"PE2G4BPFI80-SD", \
"PE2G4BPFI80LX-SD", \
"PE2G4BPFI80ZX-SD", \
"MxEG2BPI6-SD", \
"MxEG4BPI6-SD", \
"MxE2G6BPI6-SD", \
"MxEG2BPFI6-SD", \
"MxEG2BPFI6LX-SD", \
"MxEG2BPFI6ZX-SD", \
"MxEG4BPFI6-SD", \
"MxEG4BPFI6LX-SD", \
"MxEG4BPFI6ZX-SD", \
"MxE2G4BPI80-SD", \
"MxE2G4BPFI80-SD", \
"MxE2G4BPFI80LX-SD", \
"MxE2G4BPFI80ZX-SD", \
"MxE210G2BPI9SR-SD", \
"MxE210G2BPI9LR-SD", \
"PE2G4BPI80-SD", \
"PE2G2BPI80-SD", \
"PE2G2BPFI80-SD", \
"PE2G2BPFI80LX-SD", \
"PE2G2BPFI80ZX-SD", \
"PE210G2BPI40-T-SD", \
"PE2G4BPI80-SD-RB1", \
"PE310G4BPI9SR-SD", \
"PE310G4BPI9LR-SD", \
"PE2G2BPI35-SD", \
"PAC1200BPI35-SD", \
"PE2G4BPI35L-SD", \
"PE2G4BPI35-SD", \
"PE2G6BPI35-SD", \
"PE2G2BPFI35-SD", \
"PE2G2BPFI35LX-SD", \
"PE2G4BPFI35-SD", \
"PE2G4BPFI35LX-SD", \
"PE2G6BPI35-SD-CX", \
"PE2G6BPI35-SD-CX", \
"PE2G6BPI35-SD-CX", \
"PE2G6BPI35-SD-CX", \
"PE2G6BPI35-SD-CX", \
"PE2G6BPI35-SD-CX", \
"PE2G6BPI35-SD-CX", \
"PE2G6BPI35-SD-CX", \
"PE2G6BPI35-SD-CX", \
"PE2G6BPI35-SD-CX", \
"PE2G6BPI35-SD-CX", \
"PE2G6BPI35-SD-CX", \
"PE2G6BPI35-SD-CX", \
"PE2G6BPI35-SD-CX", \
"PE2G6BPI35-SD-CX", \
"PE2G6BPI35-SD-CX", \
"PE2G6BPI35-SD-CX", \
"PE2G6BPI35-SD-CX", \
"PE2G6BPI35-SD-CX", \
"PE2G6BPI35-SD-CX", \
"PE2G6BPI35-SD-CX", \
"PE2G6BPI35-SD-CX", \
"PE2G6BPI35-SD-CX", \
"PE2G6BPI35-SD-CX", \
"PE2G6BPI35-SD-CX", \
"PE2G6BPI35-SD-CX", \
"PE2G6BPI35-SD-CX", \
"PE2G6BPI35-SD-CX", \
"PE2G6BPI35-SD-CX", \
"PE2G6BPI35-SD-CX", \
"PE2G6BPI35-SD-CX", \
"PE2G6BPI35-SD-CX", \
"PE2G4BPFI35-SD-CX", \
"PE2G4BPFI35-SD-CX", \
"PE2G4BPFI35-SD-CX", \
"PE2G4BPFI35-SD-CX", \
"PE2G4BPFI35-SD-CX", \
"PE2G4BPFI35-SD-CX", \
"PE2G4BPFI35-SD-CX", \
"PE2G4BPFI35-SD-CX", \
"PE2G4BPFI35-SD-CX", \
"PE2G4BPFI35-SD-CX", \
"PE2G4BPFI35-SD-CX", \
"PE2G4BPFI35-SD-CX", \
"PE2G4BPFI35-SD-CX", \
"PE2G4BPFI35-SD-CX", \
"PE2G4BPFI35-SD-CX", \
"PE2G4BPFI35-SD-CX", \
"PE2G4BPFI35-SD-CX", \
"PE2G4BPFI35-SD-CX", \
"PE2G4BPFI35-SD-CX", \
"PE2G4BPFI35-SD-CX", \
"PE2G4BPFI35-SD-CX", \
"PE2G4BPFI35-SD-CX", \
"PE2G4BPFI35-SD-CX", \
"PE2G4BPFI35-SD-CX", \
"PE2G4BPFI35-SD-CX", \
"PE2G4BPFI35-SD-CX", \
"PE2G4BPFI35-SD-CX", \
"PE2G4BPFI35-SD-CX", \
"PE2G4BPFI35-SD-CX", \
"PE2G4BPFI35-SD-CX", \
"PE2G4BPFI35-SD-CX", \
"PE2G4BPFI35-SD-CX", \
"PE2G4BPI35-SD-CX", \
"PE2G4BPI35-SD-CX", \
"PE2G4BPI35-SD-CX", \
"PE2G4BPI35-SD-CX", \
"PE2G4BPI35-SD-CX", \
"PE2G4BPI35-SD-CX", \
"PE2G4BPI35-SD-CX", \
"PE2G4BPI35-SD-CX", \
"PE2G4BPI35-SD-CX", \
"PE2G4BPI35-SD-CX", \
"PE2G4BPI35-SD-CX", \
"PE2G4BPI35-SD-CX", \
"PE2G4BPI35-SD-CX", \
"PE2G4BPI35-SD-CX", \
"PE2G4BPI35-SD-CX", \
"PE2G4BPI35-SD-CX", \
"PE2G4BPI35-SD-CX", \
"PE2G4BPI35-SD-CX", \
"PE2G4BPI35-SD-CX", \
"PE2G4BPI35-SD-CX", \
"PE2G4BPI35-SD-CX", \
"PE2G4BPI35-SD-CX", \
"PE2G4BPI35-SD-CX", \
"PE2G4BPI35-SD-CX", \
"PE2G4BPI35-SD-CX", \
"PE2G4BPI35-SD-CX", \
"PE2G4BPI35-SD-CX", \
"PE2G4BPI35-SD-CX", \
"PE2G4BPI35-SD-CX", \
"PE2G4BPI35-SD-CX", \
"PE2G4BPI35-SD-CX", \
"PE2G4BPI35-SD-CX", \
"PE210G2BPI9-SR-SD-CX", \
"PE210G2BPI9-SR-SD-CX", \
"PE210G2BPI9-SR-SD-CX", \
"PE210G2BPI9-SR-SD-CX", \
"PE210G2BPI9-SR-SD-CX", \
"PE210G2BPI9-SR-SD-CX", \
"PE210G2BPI9-SR-SD-CX", \
"PE210G2BPI9-SR-SD-CX", \
"PE210G2BPI9-SR-SD-CX", \
"PE210G2BPI9-SR-SD-CX", \
"PE210G2BPI9-SR-SD-CX", \
"PE210G2BPI9-SR-SD-CX", \
"PE210G2BPI9-SR-SD-CX", \
"PE210G2BPI9-SR-SD-CX", \
"PE210G2BPI9-SR-SD-CX", \
"PE210G2BPI9-SR-SD-CX", \
"PE210G2BPI9-SR-SD-CX", \
"PE210G2BPI9-SR-SD-CX", \
"PE210G2BPI9-SR-SD-CX", \
"PE210G2BPI9-SR-SD-CX", \
"PE210G2BPI9-SR-SD-CX", \
"PE210G2BPI9-SR-SD-CX", \
"PE210G2BPI9-SR-SD-CX", \
"PE210G2BPI9-SR-SD-CX", \
"PE210G2BPI9-SR-SD-CX", \
"PE210G2BPI9-SR-SD-CX", \
"PE210G2BPI9-SR-SD-CX", \
"PE210G2BPI9-SR-SD-CX", \
"PE210G2BPI9-SR-SD-CX", \
"PE210G2BPI9-SR-SD-CX", \
"PE210G2BPI9-SR-SD-CX", \
"MxE310G4BPI9-SR-SD"  , \
"MxE310G4BPI9-LR-SD", \
"MxE2G8BPI80-SD", \
"MxE2G8BPI80A-SD", \
"PEG4BPFI6-SD-CS", \
"PEG4BPFI6-SD-CS", \
"PEG4BPFI6-SD-CS", \
"PEG4BPFI6-SD-CS", \
"PEG4BPFI6-SD-CS", \
"PEG4BPFI6-SD-CS", \
"PEG4BPFI6-SD-CS", \
"PEG4BPFI6-SD-CS", \
"PEG4BPFI6-SD-CS", \
"PEG4BPFI6-SD-CS", \
"PEG4BPFI6-SD-CS", \
"PEG4BPFI6-SD-CS", \
"PEG4BPFI6-SD-CS", \
"PEG4BPFI6-SD-CS", \
"PEG4BPFI6-SD-CS", \
"PEG4BPFI6-SD-CS", \
"PEG4BPFI6-SD-CS", \
"PEG4BPFI6-SD-CS", \
"PEG4BPFI6-SD-CS", \
"PEG4BPFI6-SD-CS", \
"PEG4BPFI6-SD-CS", \
"PEG4BPFI6-SD-CS", \
"PEG4BPFI6-SD-CS", \
"PEG4BPFI6-SD-CS", \
"PEG4BPFI6-SD-CS", \
"PEG4BPFI6-SD-CS", \
"PEG4BPFI6-SD-CS", \
"PEG4BPFI6-SD-CS", \
"PEG4BPFI6-SD-CS", \
"PEG4BPFI6-SD-CS", \
"PEG4BPFI6-SD-CS", \
"PEG4BPFI6-SD-CS", \
"MxE2G8BPI6-SD", \
"PE2G2BPFI35-SD", \
"" \
}


// Bypass/Tap capabilities bits
#define BP_CAP                   0x01    //BIT_0
#define BP_STATUS_CAP            0x02    //BIT_1
#define BP_STATUS_CHANGE_CAP     0x04    //BIT_2
#define SW_CTL_CAP               0x08    //BIT_3
#define BP_DIS_CAP               0x10    //BIT_4
#define BP_DIS_STATUS_CAP        0x20    //BIT_5
#define STD_NIC_CAP              0x40    //BIT_6
#define BP_PWOFF_ON_CAP          0x80    //BIT_7
#define BP_PWOFF_OFF_CAP         0x0100  //BIT_8
#define BP_PWOFF_CTL_CAP         0x0200  //BIT_9
#define BP_PWUP_ON_CAP           0x0400  //BIT_10
#define BP_PWUP_OFF_CAP          0x0800  //BIT_11
#define BP_PWUP_CTL_CAP          0x1000  //BIT_12
#define WD_CTL_CAP               0x2000  //BIT_13
#define WD_STATUS_CAP            0x4000  //BIT_14
#define WD_TIMEOUT_CAP           0x8000  //BIT_15
#define TX_CTL_CAP               0x10000 //BIT_16  
#define TX_STATUS_CAP            0x20000 //BIT_17  
#define TAP_CAP                  0x40000   //BIT_18 
#define TAP_STATUS_CAP           0x80000   //BIT_19 
#define TAP_STATUS_CHANGE_CAP    0x100000  //BIT_20 
#define TAP_DIS_CAP              0x200000 //BIT_21
#define TAP_DIS_STATUS_CAP       0x400000 //BIT_22
#define TAP_PWUP_ON_CAP          0x800000 //BIT_23
#define TAP_PWUP_OFF_CAP         0x1000000 //BIT 24
#define TAP_PWUP_CTL_CAP         0x2000000 //BIT 25
#define NIC_CAP_NEG              0x4000000 //BIT 26
#define TPL_CAP                  0x8000000 //BIT 27
#define DISC_CAP                 0x10000000 //BIT 28
#define DISC_DIS_CAP             0x20000000 //BIT 29
#define DISC_PWUP_CTL_CAP        0x40000000 //BIT 30

// Bypass/Tap extended capabilities bits
#define NOT_DEFINED_CAP_EX       0x00000000
#define TPL2_CAP_EX              0x00000001
#define TX_CTL2_CAP_EX           0x00000002

// Watchdog  capabilities 
#define WD_MIN_TIME_MASK(val)      (val & 0xf)
#define WD_STEP_COUNT_MASK(val)    ((val & 0xf) << 5)
#define WDT_STEP_TIME              0x10    //BIT_4

#define WD_MIN_TIME                100  // ms
#define WD_STEP_COUNT              4    // 0x0F
#define WD_MAX_VAL                 ((1<<WD_STEP_COUNT)-1) // 15

#define WD_MIN_TIME_GET(desc)   ((desc) & 0xf)
#define WD_STEP_COUNT_GET(desc) (((desc)>>5) & 0xf)
#define WDT_STEP_TIME_GET(desc) (((desc)&WDT_STEP_TIME)?1:0)

#define MODE_UNDEFINED         0x00
#define MODE_DISCONNECT        0x01
#define MODE_BYPASS            0x02
#define MODE_TAP               0x03

// Bypass API flags states
enum _BYPASS_CMD_FLAGS {
     BP_CMD_ON=1,
     BP_CMD_OFF=2,
     BP_CMD_GET=1,
     BP_CMD_UNSUPPORTED=3,
     BP_CMD_UNDEFINED=0,

};

// WDT states
enum _WDT_STATES {
     WDT_STATE_UNKNOWN=-1,
     WDT_STATE_STARTED,
     WDT_STATE_STOPPED,
     WDT_STATE_EXPIRED
};	     

// UINT64 flags definitions
#define  FL_WDT_ON_OFF(a)      (((a)&3)<<0)
#define  FL_WDT_EXP_BP_TAP(a)  (((a)&3)<<2)
#define  FL_BP_ON_OFF(a)       (((a)&3)<<4)
#define  FL_BP_DIS_ON_OFF(a)   (((a)&3)<<6)
#define  FL_BP_PWOFF_ON_OFF(a) (((a)&3)<<8)
#define  FL_BP_PWUP_ON_OFF(a)  (((a)&3)<<10)
#define  FL_TAP_ON_OFF(a)      (((a)&3)<<12)
#define  FL_TAP_DIS_ON_OFF(a)  (((a)&3)<<14)
#define  FL_TAP_PWUP_ON_OFF(a) (((a)&3)<<16)
#define  FL_TX_ON_OFF(a)       (((a)&3)<<18)
#define  FL_NIC_ON_OFF(a)      (((a)&3)<<20)
#define  FL_WDT_EXP_TIME(a)    (((a)&3)<<22)
#define  FL_BP_PREVIOUS(a)     (((a)&3)<<24)
#define  FL_TWO_PORT_LINK(a)   (((a)&3)<<26)


// flags structure
typedef    union  _BP_FLAGS {
    struct  {
        UINT64 wdt_on_off:2;     // 3<<0
        UINT64 wdt_exp_bp_tap_disc:2; // 3<<2
        UINT64 bp_on_off:2;      // 3<<4
        UINT64 bp_dis_on_off:2;  // 3<<6
        UINT64 bp_pwoff_on_off:2;// 3<<8
        UINT64 bp_pwup_on_off:2; // 3<<10
        UINT64 tap_on_off:2;     // 3<<12
        UINT64 tap_dis_on_off:2; // 3<<14
        UINT64 tap_pwup_on_off:2;// 3<<16
        UINT64 tx_on_off:2;      // 3<<18
        UINT64 nic_on_off:2;     // 3<<20
        UINT64 wdt_exp_time:2;   // 3<<22
        UINT64 bp_previous:2;    // 3<<24
        UINT64 two_port_link:2;  // 3<<26
//Added 2007.11.12        
        UINT64 disc_on_off:2;      // 3<<28
        UINT64 disc_dis_on_off:2;  // 3<<30
        UINT64 disc_previous:2;    // 3<<32
        UINT64 disc_pwup_on_off:2; // 3<<34
        UINT64 bp_wait_at_pwup:2;  // 3<<36
        UINT64 bp_hw_reset:2;      // 3<<38
        UINT64 tap_previous:2;     // 3<<40
        UINT64 reserved:22;       
    } bb;
    UINT64 value; 
} BP_FLAGS,*PBP_FLAGS;

#define BP_CMD_MASK_WDT_ON_OFF			(0x0000000000000003L<<0)
#define BP_CMD_MASK_WDT_EXP_BP_TAP_DISC	(0x0000000000000003L<<2)
#define BP_CMD_MASK_BP_ON_OFF			(0x0000000000000003L<<4)
#define BP_CMD_MASK_BP_DIS_ON_OFF		(0x0000000000000003L<<6)
#define BP_CMD_MASK_BP_PWOFF_ON_OFF		(0x0000000000000003L<<8)
#define BP_CMD_MASK_BP_PWUP_ON_OFF		(0x0000000000000003L<<10)
#define BP_CMD_MASK_TAP_ON_OFF			(0x0000000000000003L<<12)
#define BP_CMD_MASK_TAP_DIS_ON_OFF		(0x0000000000000003L<<14)
#define BP_CMD_MASK_TAP_PWUP_ON_OFF		(0x0000000000000003L<<16)
#define BP_CMD_MASK_TX_ON_OFF			(0x0000000000000003L<<18)
#define BP_CMD_MASK_NIC_ON_OFF			(0x0000000000000003L<<20)
#define BP_CMD_MASK_WDT_EXP_TIME		(0x0000000000000003L<<22)
#define BP_CMD_MASK_BP_PREVIOUS			(0x0000000000000003L<<24)
#define BP_CMD_MASK_TWO_PORT_LINK		(0x0000000000000003L<<26)
#define BP_CMD_MASK_DISC_ON_OFF			(0x0000000000000003L<<28)
#define BP_CMD_MASK_DISC_DIS_ON_OFF		(0x0000000000000003L<<30)
#define BP_CMD_MASK_DISC_PREVIOUS		(0x0000000300000000L<<0)
#define BP_CMD_MASK_DISC_PWUP_ON_OFF	(0x0000000300000000L<<2)
#define BP_CMD_MASK_BP_WAIT_AT_PWUP		(0x0000000300000000L<<4)
#define BP_CMD_MASK_BP_HW_RESET			(0x0000000300000000L<<6)
#define BP_CMD_MASK_TAP_PREVIOUS		(0x0000000300000000L<<8)

#define BP_CMD_MASK                 0x000003FFFFFFFFFF
#define BP_CMD_GET_MASK            (0x5555555555555555 & BP_CMD_MASK)
#define BP_CMD_SET_MASK            (0xAAAAAAAAAAAAAAAA & BP_CMD_MASK)


// API interface IN OUT structures 
typedef struct _BP_IN_PARAMS {
   BP_FLAGS flags;   
   UINT32   timeout_ms;
   UINT32   wdt_exp_mode;
   UINT32   reserved[8];
} BP_IN_PARAMS;

typedef struct _BP_OUT_PARAMS {
   BP_FLAGS flags;   
   UINT32 timeout_ms;
   UINT32 exp_time_ms;
   UINT32 bp_cap;
   UINT32 bp_cap_ext;
   UINT32 wdt_cap;
   UINT32 pb_dev_type;
   UINT32 reserved[4];
} BP_OUT_PARAMS;

typedef struct _BYPASS_CMD_{
    UINT32 BpDeviceIndex;    // Zero based index of Bypass devices
    UINT32 Command;
    UINT32 Status;
    union  {
        GUID_STR NicGuidStr; 
        BP_IN_PARAMS  params;
    };
} BYPASS_CMD,*PBYPASS_CMD;

typedef struct _BYPASS_CMD_STATE{
    UINT32 BpDeviceIndex;    // Zero based index of Bypass devices
    UINT32 Command;
    UINT32 Status;           
    union  {
        GUID_STR NicGuidStr; 
        BP_OUT_PARAMS  params;
    };
} BYPASS_CMD_STATE,*PBYPASS_CMD_STATE;

enum _BP_API_CMD {
  BP_CMD_IS_BYPASS=0,
  BP_CMD_GET_NUM,
  BP_CMD_GET_DEVICE_INFO,
  BP_CMD_GET_CAP,
  BP_CMD_RESET_WDT,
  BP_CMD_SET_STATE,
  BP_CMD_GET_STATE,
  BP_CMD_RESCAN,
  BP_CMD_SET_AUTO_WDT,
  BP_CMD_GET_AUTO_WDT,
  BP_CMD_LAST
};

enum _BP_CMD_STATUS {
  BP_STATUS_MASTER=0,
  BP_STATUS_SLAVE=1,
  BP_STATUS_UNKNOWN=-1,
  BP_STATUS_UNSUPPORTED=-2,
  BP_STATUS_DRIVER_BUSY=-3,
  BP_STATUS_DEVICE_BUSY=-4,
  BP_STATUS_TPL_ENABLED=-5,
  BP_STATUS_INTERNAL_ERROR=-6,
  BP_STATUS_NOT_CONNECTED=0x40000000,
  BP_STATUS_OK=0
};

typedef enum _BP_CMD_STATUS BPSTATUS;

#define BP_BUS_INFO(pDev,Slave) ((pDev)->BusNumber<<16) | ((pDev)->DeviceNumber<<8)| \
                   ((Slave)?1:0) | ( ((pDev)->PortBase[((Slave)?1:0)].PortBaseType)?0:BP_STATUS_NOT_CONNECTED);

#define BP_BUS_FROM_STATUS(status) (0x3fff&((status)>>16))
#define BP_DEV_FROM_STATUS(status) (0xff&((status)>>8))
#define BP_FUN_FROM_STATUS(status) (0xff&(status))
#define BP_STATUS_CONNECTED(status) (((status)&BP_STATUS_NOT_CONNECTED)?0:1)


#endif
