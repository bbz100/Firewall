BOOL InstallDriver(
    IN SC_HANDLE  SchSCManager,
    IN LPCTSTR    DriverName,
    IN LPCTSTR    ServiceExe
){
    SC_HANDLE  schService;
    DWORD      err;
 
    // NOTE: This creates an entry for a standalone driver. If this
    //       is modified for use with a driver that requires a Tag,
    //       Group, and/or Dependencies, it may be necessary to
    //       query the registry for existing driver information
    //       (in order to determine a unique Tag, etc.).
    schService = CreateService (SchSCManager,          // SCManager database
                                DriverName,           // name of service
                                DriverName,           // name to display
                                SERVICE_ALL_ACCESS,    // desired access
                                SERVICE_KERNEL_DRIVER, // service type
                                SERVICE_DEMAND_START,  // start type
                                SERVICE_ERROR_NORMAL,  // error control type
                                ServiceExe,            // service's binary
                                NULL,                  // no load ordering group
                                NULL,                  // no tag identifier
                                NULL,                  // no dependencies
                                NULL,                  // LocalSystem account
                                NULL                   // no password
                                );

    if (schService == NULL) {
        err = GetLastError();
        if (err == ERROR_SERVICE_EXISTS){
            PRINTF(("failure: CreateService, ERROR_SERVICE_EXISTS\n"));
        } else {
            PRINTF(("failure: CreateService %d)\n", err));
        }
        return FALSE;
    } else {
        PRINTF(("CreateService SUCCESS\n"));
    }

    CloseServiceHandle (schService);

    return TRUE;
}



BOOL RemoveDriver(IN SC_HANDLE  SchSCManager,IN LPCTSTR    DriverName){
    SC_HANDLE  schService;
    BOOL       ret;
    DWORD      err;

    schService = OpenService (SchSCManager,DriverName,SERVICE_ALL_ACCESS);

    if (schService == NULL) {
        err = GetLastError();
        switch(err) {
		   case ERROR_BAD_DRIVER:
              // A common cause of failure (easier to read than an error code)
              PRINTF(("failure: OpenService, ERROR_BAD_DRIVER\n"));
			  break;
		   case ERROR_DRIVER_BLOCKED:
              // A common cause of failure (easier to read than an error code)
              PRINTF(("failure: OpenService, ERROR_DRIVER_BLOCKED\n"));
			  break;
		   case ERROR_FILE_NOT_FOUND:
              // A common cause of failure (easier to read than an error code)
              PRINTF(("failure: OpenService, ERROR_FILE_NOT_FOUND\n"));
			  break;
		   case ERROR_SERVICE_ALREADY_RUNNING:
              // A common cause of failure (easier to read than an error code)
              PRINTF(("failure: OpenService, ERROR_SERVICE_ALREADY_RUNNING\n"));
			  break;
		   case ERROR_SERVICE_DOES_NOT_EXIST:
              // A common cause of failure (easier to read than an error code)
              PRINTF(("failure: OpenService, ERROR_SERVICE_DOES_NOT_EXIST\n"));
			  break;
		   case ERROR_SERVICE_NOT_ACTIVE:
              // A common cause of failure (easier to read than an error code)
              PRINTF(("failure: OpenService, ERROR_SERVICE_NOT_ACTIVE\n"));
			  break;
		   default:
              PRINTF(("failure: OpenService %d\n", err ));
		}
        return FALSE;
    }

    ret = DeleteService (schService);

    if (ret)  {
        PRINTF(("DeleteService SUCCESS\n"));
    } else {
        err = GetLastError();
        switch(err) {
		   case ERROR_BAD_DRIVER:
              // A common cause of failure (easier to read than an error code)
              PRINTF(("failure: DeleteService, ERROR_BAD_DRIVER\n"));
			  break;
		   case ERROR_DRIVER_BLOCKED:
              // A common cause of failure (easier to read than an error code)
              PRINTF(("failure: DeleteService, ERROR_DRIVER_BLOCKED\n"));
			  break;
		   case ERROR_FILE_NOT_FOUND:
              // A common cause of failure (easier to read than an error code)
              PRINTF(("failure: DeleteService, ERROR_FILE_NOT_FOUND\n"));
			  break;
		   case ERROR_SERVICE_ALREADY_RUNNING:
              // A common cause of failure (easier to read than an error code)
              PRINTF(("failure: DeleteService, ERROR_SERVICE_ALREADY_RUNNING\n"));
			  break;
		   case ERROR_SERVICE_DOES_NOT_EXIST:
              // A common cause of failure (easier to read than an error code)
              PRINTF(("failure: DeleteService, ERROR_SERVICE_DOES_NOT_EXIST\n"));
			  break;
		   case ERROR_SERVICE_NOT_ACTIVE:
              // A common cause of failure (easier to read than an error code)
              PRINTF(("failure: DeleteService, ERROR_SERVICE_NOT_ACTIVE\n"));
			  break;
		   default:
              PRINTF(("failure: DeleteService %d\n", err ));
		}
    }

    CloseServiceHandle (schService);

    return ret;
}

BOOL StartDriver(IN SC_HANDLE  SchSCManager,IN LPCTSTR    DriverName){
    SC_HANDLE  schService;
    BOOL       ret;
    DWORD      err;

    schService = OpenService (SchSCManager,DriverName,SERVICE_ALL_ACCESS);

    if (schService == NULL){
        err = GetLastError();
        switch(err) {
		   case ERROR_BAD_DRIVER:
              // A common cause of failure (easier to read than an error code)
              PRINTF(("failure: OpenService, ERROR_BAD_DRIVER\n"));
			  break;
		   case ERROR_DRIVER_BLOCKED:
              // A common cause of failure (easier to read than an error code)
              PRINTF(("failure: OpenService, ERROR_DRIVER_BLOCKED\n"));
			  break;
		   case ERROR_FILE_NOT_FOUND:
              // A common cause of failure (easier to read than an error code)
              PRINTF(("failure: OpenService, ERROR_FILE_NOT_FOUND\n"));
			  break;
		   case ERROR_SERVICE_ALREADY_RUNNING:
              // A common cause of failure (easier to read than an error code)
              PRINTF(("failure: OpenService, ERROR_SERVICE_ALREADY_RUNNING\n"));
			  break;
		   case ERROR_SERVICE_DOES_NOT_EXIST:
              // A common cause of failure (easier to read than an error code)
              PRINTF(("failure: OpenService, ERROR_SERVICE_DOES_NOT_EXIST\n"));
			  break;
		   case ERROR_SERVICE_NOT_ACTIVE:
              // A common cause of failure (easier to read than an error code)
              PRINTF(("failure: OpenService, ERROR_SERVICE_NOT_ACTIVE\n"));
			  break;
		   default:
              PRINTF(("failure: OpenService %d\n", err ));
		}
        return FALSE;
    }

    ret = StartService (schService,    // service identifier
                        0,             // number of arguments
                        NULL           // pointer to arguments
                        );
    if (ret) {
        PRINTF(("StartService SUCCESS\n"));
    } else {
        err = GetLastError();
        switch(err) {
		   case ERROR_BAD_DRIVER:
              // A common cause of failure (easier to read than an error code)
              PRINTF(("failure: StartService, ERROR_BAD_DRIVER\n"));
			  break;
		   case ERROR_DRIVER_BLOCKED:
              // A common cause of failure (easier to read than an error code)
              PRINTF(("failure: StartService, ERROR_DRIVER_BLOCKED\n"));
			  break;
		   case ERROR_FILE_NOT_FOUND:
              // A common cause of failure (easier to read than an error code)
              PRINTF(("failure: StartService, ERROR_FILE_NOT_FOUND\n"));
			  break;
		   case ERROR_SERVICE_ALREADY_RUNNING:
              // A common cause of failure (easier to read than an error code)
              PRINTF(("failure: StartService, ERROR_SERVICE_ALREADY_RUNNING\n"));
			  break;
		   case ERROR_SERVICE_DOES_NOT_EXIST:
              // A common cause of failure (easier to read than an error code)
              PRINTF(("failure: StartService, ERROR_SERVICE_DOES_NOT_EXIST\n"));
			  break;
		   case ERROR_SERVICE_NOT_ACTIVE:
              // A common cause of failure (easier to read than an error code)
              PRINTF(("failure: StartService, ERROR_SERVICE_NOT_ACTIVE\n"));
			  break;
		   case ERROR_GEN_FAILURE:
              // A common cause of failure (easier to read than an error code)
              PRINTF(("failure: StartService, ERROR_GEN_FAILURE (A device attached to the system is not functioning.)\n"));
			  break;
		   default:
              PRINTF(("failure: StartService %d\n", err ));
		}
    }

    CloseServiceHandle (schService);
    return ret;
}

BOOL StopDriver(IN SC_HANDLE  SchSCManager, IN LPCTSTR    DriverName){
    SC_HANDLE       schService;
    BOOL            ret;
    DWORD           err;
    SERVICE_STATUS  serviceStatus;

    schService = OpenService (SchSCManager,DriverName,SERVICE_ALL_ACCESS);
    if (schService == NULL) {
        err = GetLastError();
        switch(err) {
		   case ERROR_BAD_DRIVER:
              // A common cause of failure (easier to read than an error code)
              PRINTF(("failure: OpenService, ERROR_BAD_DRIVER\n"));
			  break;
		   case ERROR_DRIVER_BLOCKED:
              // A common cause of failure (easier to read than an error code)
              PRINTF(("failure: OpenService, ERROR_DRIVER_BLOCKED\n"));
			  break;
		   case ERROR_FILE_NOT_FOUND:
              // A common cause of failure (easier to read than an error code)
              PRINTF(("failure: OpenService, ERROR_FILE_NOT_FOUND\n"));
			  break;
		   case ERROR_SERVICE_ALREADY_RUNNING:
              // A common cause of failure (easier to read than an error code)
              PRINTF(("failure: OpenService, ERROR_SERVICE_ALREADY_RUNNING\n"));
			  break;
		   case ERROR_SERVICE_DOES_NOT_EXIST:
              // A common cause of failure (easier to read than an error code)
              PRINTF(("failure: OpenService, ERROR_SERVICE_DOES_NOT_EXIST\n"));
			  break;
		   case ERROR_SERVICE_NOT_ACTIVE:
              // A common cause of failure (easier to read than an error code)
              PRINTF(("failure: OpenService, ERROR_SERVICE_NOT_ACTIVE\n"));
			  break;
		   default:
              PRINTF(("failure: OpenService %d\n", err ));
		}
        return FALSE;
    }

    ret = ControlService (schService,SERVICE_CONTROL_STOP,&serviceStatus);
    if (ret){
        PRINTF(("ControlService SUCCESS\n"));
    } else {
        err = GetLastError();
        switch(err) {
		   case ERROR_BAD_DRIVER:
              // A common cause of failure (easier to read than an error code)
              PRINTF(("failure: ControlService, ERROR_BAD_DRIVER\n"));
			  break;
		   case ERROR_DRIVER_BLOCKED:
              // A common cause of failure (easier to read than an error code)
              PRINTF(("failure: ControlService, ERROR_DRIVER_BLOCKED\n"));
			  break;
		   case ERROR_FILE_NOT_FOUND:
              // A common cause of failure (easier to read than an error code)
              PRINTF(("failure: ControlService, ERROR_FILE_NOT_FOUND\n"));
			  break;
		   case ERROR_SERVICE_ALREADY_RUNNING:
              // A common cause of failure (easier to read than an error code)
              PRINTF(("failure: ControlService, ERROR_SERVICE_ALREADY_RUNNING\n"));
			  break;
		   case ERROR_SERVICE_DOES_NOT_EXIST:
              // A common cause of failure (easier to read than an error code)
              PRINTF(("failure: ControlService, ERROR_SERVICE_DOES_NOT_EXIST\n"));
			  break;
		   case ERROR_SERVICE_NOT_ACTIVE:
              // A common cause of failure (easier to read than an error code)
              PRINTF(("failure: ControlService, ERROR_SERVICE_NOT_ACTIVE\n"));
			  break;
		   default:
              PRINTF(("failure: ControlService %d\n", err ));
		}
    }
    CloseServiceHandle (schService);
    return ret;
}

HANDLE   OpenDevice(IN LPCTSTR  DeviceName   ) {
    char     completeDeviceName[64]="";
    HANDLE   hDevice;
    // Create a \\.\XXX device name that CreateFile can use
    strcat (completeDeviceName,"\\\\.\\");
    strcat (completeDeviceName,DeviceName );
    hDevice = CreateFile (completeDeviceName,GENERIC_READ | GENERIC_WRITE,0,NULL,
                          OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
    return hDevice;
}