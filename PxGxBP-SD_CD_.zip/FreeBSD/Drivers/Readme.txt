
The driver that needs to be used for these products set is Intel standard driver - em-<ver> for 
1-Gigabit adapters or ix-<ver> for 10-Gigabit adapters.

Need to select the correct em or ix driver of Intel according to the OS you are using.

Usually the em driver is installed on the OS by default and can be used for 1-Gigabit products.
