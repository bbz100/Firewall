                 Silicom Windows Bypass Control Utility 
                 
Usage:
bpctl_util <info|help>
bpctl_util <start|stop> start/stop BpServ service (service install/uninstall via bp utility)
Bypass control operation:
bpctl_util [-d <val>] <command> [parameters]
        -d bypass device number min is 1
<command>    - bypass control command (see Commands List).
[parameters] - set_bypass_wd command:
                   WDT timeout interval, msec (0 for disabling WDT).
               blink_test command:
                   LED blinking timeout interval, sec.
               set_bypass/set_bypass_pwoff/set_bypass_pwup/set_dis_bypass commands:
                   on/off for enable/disable Bypass
               set_std_nic command:
                   on/off for enable/disable Standard NIC mode
               set_tx command:
                   on/off for enable/disable transmit
               set_tpl command:
                   on/off for enable/disable TPL
               set_wait_at_pwup command:
                   on/off for enable/disable wait_at_pwup
               set_hw_reset command:
                   on/off for enable/disable hw_reset
               set_tap/set_tap_pwup/set_dis_tap commands:
                   on/off for enable/disable TAP
               set_disc/set_disc_pwup/set_dis_disc commands:
                   on/off for enable/disable Disc
               set_wd_exp_mode command:
                   bypass/tap/disc for bypass/tap/disc mode
               set_wd_autoreset command:
                   WDT autoreset interval, msec (0 for disabling WDT autoreset).
info         - print Program Information.
help         - print this message.
   Commands List:
get_dev_num      - get total number of installed devices
is_bypass        - check if device is a Bypass/TAP controlling device
get_bypass_slave - get the second port participate in the Bypass/TAP pair
get_bypass_caps  - obtain Bypass/TAP capabilities information
get_wd_set_caps  - obtain watchdog timer settings capabilities
get_bypass_info  - get bypass/TAP info
get_nic_info   - get NIC info
get_pci_info     - get PCI info
get_drv_ver      - host driver version
set_bypass       - set Bypass mode state
get_bypass       - get Bypass mode state
get_bypass_change - get change of Bypass mode state from last status check
set_dis_bypass   - set Disable Bypass mode
get_dis_bypass   - get Disable Bypass mode state
set_bypass_pwoff - set Bypass mode at power-off state
get_bypass_pwoff - get Bypass mode at power-off state
set_bypass_pwup  - set Bypass mode at power-up state
get_bypass_pwup  - get Bypass mode at power-up state
set_std_nic      - set Standard NIC mode of operation
get_std_nic      - get Standard NIC mode settings
set_bypass_wd    - set watchdog state
get_bypass_wd    - get watchdog state
get_wd_time_expire - get watchdog expired time
reset_bypass_wd - reset watchdog timer
set_tx      - set transmit enable / disable
get_tx      - get transmitter state (enabled / disabled)
set_tpl      - set TPL enable / disable
get_tpl      - get TPL state (enabled / disabled)
set_wait_at_pwup      - set wait_at_pwup enable / disable
get_wait_at_pwup      - get wait_at_pwup (enabled / disabled)
set_hw_reset          - set hw_reset enable / disable
get_hw_reset          - get hw_reset (enabled / disabled)
set_tap       - set TAP mode state
get_tap       - get TAP mode state
get_tap_change - get change of TAP mode state from last status check
set_dis_tap   - set Disable TAP mode
get_dis_tap   - get Disable TAP mode state
set_tap_pwup  - set TAP mode at power-up state
get_tap_pwup  - get TAP mode at power-up state
set_disc       - set Disc mode state
get_disc       - get Disc mode state
get_disc_change - get change of Disc mode state from last status check
set_dis_disc   - set Disable Disc mode
get_dis_disc   - get Disable Disc mode state
set_disc_pwup  - set Disc mode at power-up state
get_disc_pwup  - get Disc mode at power-up state
set_wd_exp_mode - set adapter state when WDT expired
get_wd_exp_mode - get adapter state when WDT expired


Bypass control example: bpctl_util -d 1 get_bypass_info
                        bpctl_util -d 1 set_bypass on
