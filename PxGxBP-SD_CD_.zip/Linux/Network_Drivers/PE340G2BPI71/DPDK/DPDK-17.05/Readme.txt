This patch is needed for the PE340G2BPI71 due to the bypass / Disconnect mode,
when product is in this mode the transceiver is not accesable and due to that there is issue loading the driver
Patch enable loading the driver also in bypass mode and then will work correctly when switching to inline mode.